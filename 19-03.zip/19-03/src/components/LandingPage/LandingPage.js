import React, { Component } from 'react';
import Header from './Header';
import Main from './Main';
import Footer from './Footer';
import './landing.css';

class LandingPage extends Component {
    render(){
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="landing-bg">
                        <Header/>
                          <Main/>
                        <Footer/>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default LandingPage;
