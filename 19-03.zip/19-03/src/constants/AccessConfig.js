const ManageEquipment = "ppp.CCUI_Manage_Equipment";
const BalanceLabour = "ppp.CCUI_Balance_Labour";
const ManageOrder = "ppp.CCUI_Manage_Order";
const Dashboard = "ppp.CCUI_Dashboard";
const Report = "ppp.CCUI_Report";
const Exceptions = "ppp.CCUI_Exceptions";
const ManageInventory = "ppp.CCUI_Manage_Inventory";
const WorkMonitoring = "ppp.CCUI_Work_Monitoring";

export default {ManageEquipment, BalanceLabour,
				ManageOrder, Dashboard,
				Report, Exceptions,
				ManageInventory, WorkMonitoring}