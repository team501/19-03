/**
 * Data Table
 */
import React from 'react';
// MUI data table 
import MUIDataTable from "mui-datatables";
//axios call
import axios from 'axios';
import {baseURL} from '../../../services/Config.js';

// MUI Theme - added to customize cell Theme  
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

// rct card box
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

// intl messages
import IntlMessages from 'Util/IntlMessages';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";
	
class DataTable extends React.Component {
	
	 constructor(props) {
    super(props);
	this.state = {  data: [],
					inductsVal: [],
					isLoading:true,
					colorCode: ''
				 };
	}
		

	
	linkState = this.props.location.state === undefined ? '' : this.props.location.state.nextLink
	
	async componentWillMount() {
		axios.get(baseURL+'inductionstatus/'+ sessionStorage.getItem("username") )
			 .then(res => {
			    console.log(res.data); 
				let inductsVal = res.data.map(list => list.inducts_per_hour);

				this.setState({ data: res.data,
								inductsVal: inductsVal,
			    				isLoading:false}); 
			}).catch(function (error) {
				console.log(error);
		  });
	}
	  setColor(){
		
		console.log("Here it is :"+ this.state.inductsVal);
		let val = this.state.inductsVal.map(value => {
			let clrCode = value > 1150 ?  '#D3D3D3' : (value < 800 ? "#CD5C5C" :"#ffcb0c" );
			this.setState({ colorCode: clrCode}); 
			console.log("Finally : "+ this.state.colorCode);
		})
		
	  }
	  
	  colorCd = this.state.inductsVal.map(value => {
			let clrCode = value > 1150 ?  '#D3D3D3' : (value < 800 ? "#CD5C5C" :"#ffcb0c" );
			this.setState({ colorCode: clrCode}); 
			console.log("Finally : "+ this.state.colorCode);
			return(this.state.colorCode);
		})
	  
	  getMuiTheme = () => createMuiTheme({
	  overrides: {
	   
		MUIDataTableBodyCell: {
		  root: {			
			  width: 60,
			   backgroundColor: '#D3D3D3',
			    //to add color to the 1st column 
			  '&:nth-child(2)': {	
				
				backgroundColor: '#CD5C5C',
				width: 60
			  },
			   //to add text-color to the 5th column 
			    '&:nth-child(10)': {			  
				color: '#CD5C5C'					  			
			  }
		  }
		}
	  }
	})
	
	render() {
	    const rows = this.state.data; 
				console.log(this.state.inductsVal);	
        {this.setColor()}

		const columns = ["", "Runtime", "Total Inducts", "Induct/hour", "Utilization", "Peak Rate", "Peak Rate", "Average Rate", "Current user", "Last Scan"];
		
		const options = {
			filterType: 'dropdown',
			responsive: 'stacked',
			selectableRows: false // to remove the checkbox
		};
		const { match } = this.props;

		return (
			<div className="data-table-wrapper">
				<div>
				<div className="breadScrum">Unit Sorter Dashboard >> Sorter A  >> <strong> Induction Status</strong> </div>

				<RctCollapsibleCard reloadable fullBlock>
					<MuiThemeProvider theme={this.getMuiTheme()}>
					<MUIDataTable
						title={"Induction Status"}
						data={rows.map(item => {
							    console.log(item.inducts_per_hour);	
									
								return [
									"Station A",
									item.runtime,
									item.total_inducts,
									item.inducts_per_hour,
									item.utilization,
									item.peak_rate,
									item.min_rate,
									item.avg_rate,
									item.current_usr,
									item.last_scan
								]
								
							})}
						columns={columns}
						options={options}
					/>
					</MuiThemeProvider>
				</RctCollapsibleCard>
				</div>
			</div>
		);
	}
}

export default DataTable;
